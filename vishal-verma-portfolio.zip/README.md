# Vishal Verma — Portfolio

A premium, static personal portfolio for Vishal Verma — Java Backend Developer / Software Engineer.
Built with **React + Tailwind CSS + Framer Motion + Lenis**. No backend, no database, no auth.

## Run locally

```bash
yarn install
yarn start        # dev server on http://localhost:3000
yarn build        # production build in /build
```

## Deploy (Vercel / Netlify)

- **Vercel:** import the repo → Framework preset "Create React App" → build command `yarn build`, output `build`.
- **Netlify:** build command `yarn build`, publish directory `build`.

## Updating content (no deep coding needed)

Everything content-related lives in **`src/content.js`** — one file. Folders live under `public/`:

| What | Where to put the file | What to edit |
|---|---|---|
| Profile photo | `public/images/profile/` | `personal.profilePhoto` in `src/content.js` |
| Gallery photos | `public/images/gallery/` | add/remove an entry in `gallery` |
| Project covers | `public/images/projects/` | set `image` in a `projects` entry |
| Certificates (JPG/PNG/PDF) | `public/certificates/` | add an entry in `certificates` |
| Resume PDF | `public/resume/` | set `resume.file` |
| Downloadable project JARs | `public/jars/` | set `jar` in a `projects` entry |

Relative paths like `images/gallery/photo.jpg` point inside `public/`. Full `https://` URLs also work.

### Common edits (all in `src/content.js`)

- **Contact details:** `personal.email`, `personal.phone`, `personal.linkedin`, `personal.github`, `personal.location`
- **Profile photo:** `personal.profilePhoto`
- **Experience:** edit the `experience` array (description and bullet points are plain text)
- **Projects:** edit the `projects` array; add `github` / `live` URLs to show those buttons. For a downloadable runnable JAR, drop the file into `public/jars/` and set `jar` (e.g. `"jars/nbfc-dsa360.jar"`) — the **Download JAR** button appears on the card automatically once the file exists. Until then a "JAR coming soon" note is shown.
- **Gallery:** each entry needs `id`, `title`, `caption`, `category` (Professional / Events / Projects / Awards / Other) and `src`
- **Certificates:** each entry needs `id`, `name`, `issuer`, `date`, `description`, `file`, and `type` (`"image"` or `"pdf"`). PDFs open in a new tab via the View Certificate button; images open in a large preview.
- **Achievements:** add entries to the `achievements` array (`id`, `title`, `detail`, `year`)
- **Resume:** drop your PDF into `public/resume/` and set `resume.file`. The Download and Preview buttons activate automatically once the PDF exists.

Note: a static website cannot accept uploads through a public form — adding or replacing files is always done through the project files above, exactly as designed.
