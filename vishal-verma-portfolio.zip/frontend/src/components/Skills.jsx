import {
  Code2, Coffee, Braces, Server, Leaf, Workflow, Globe, Layers, Database,
  Boxes, Gauge, Table, ListOrdered, Wrench, GitBranch, Github, Package,
  Send, Container, Terminal, Monitor, FileCode, Palette, Atom, Wind,
} from "lucide-react";
import { SectionHeader, Stagger, FadeUp } from "./Motion";
import { skillCategories } from "../content";

const iconMap = {
  Code2, Coffee, Braces, Server, Leaf, Workflow, Globe, Layers, Database,
  Boxes, Gauge, Table, ListOrdered, Wrench, GitBranch, Github, Package,
  Send, Container, Terminal, Monitor, FileCode, Palette, Atom, Wind,
};

export default function Skills() {
  return (
    <section id="skills" className="py-24 sm:py-32 scroll-mt-20 bg-secondary/30 border-y border-border">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Technical Skills"
          title="A backend toolkit built for production"
          description="Languages, frameworks, databases and tools I use to design, build and ship reliable server-side systems."
          testid="skills-section"
        />

        <Stagger className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {skillCategories.map((cat, ci) => {
            const CatIcon = iconMap[cat.icon] || Code2;
            return (
              <FadeUp key={cat.name} className={ci === 1 ? "lg:row-span-1" : ""}>
                <div
                  className="rounded-2xl border border-border bg-card p-6 h-full transition-all duration-300 hover:border-primary/40 hover:-translate-y-1"
                  data-testid={`skill-category-${ci}`}
                >
                  <div className="flex items-center gap-3 mb-5">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/25 flex items-center justify-center text-primary">
                      <CatIcon className="h-5 w-5" />
                    </div>
                    <h3 className="font-heading font-semibold text-lg text-foreground">{cat.name}</h3>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {cat.skills.map((s) => {
                      const SkillIcon = iconMap[s.icon] || Code2;
                      return (
                        <span
                          key={s.name}
                          className="inline-flex items-center gap-1.5 tag-chip"
                          data-testid={`skill-chip-${s.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`}
                        >
                          <SkillIcon className="h-3.5 w-3.5" />
                          {s.name}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </FadeUp>
            );
          })}
        </Stagger>
      </div>
    </section>
  );
}
