import { useState, useEffect } from "react";
import { Github, ExternalLink, FolderGit2, Clock, FileDown, FileWarning } from "lucide-react";
import { SectionHeader, Stagger, FadeUp } from "./Motion";
import { projects } from "../content";

function useJarAvailability() {
  const [available, setAvailable] = useState({});
  useEffect(() => {
    let cancelled = false;
    projects.forEach((p) => {
      if (!p.jar || /^https?:\/\//.test(p.jar)) {
        setAvailable((m) => ({ ...m, [p.id]: Boolean(p.jar) }));
        return;
      }
      fetch(`/${p.jar}`, { method: "HEAD" })
        .then((r) => {
          const type = r.headers.get("content-type") || "";
          if (!cancelled) setAvailable((m) => ({ ...m, [p.id]: r.ok && !type.includes("text/html") }));
        })
        .catch(() => {
          if (!cancelled) setAvailable((m) => ({ ...m, [p.id]: false }));
        });
    });
    return () => { cancelled = true; };
  }, []);
  return available;
}

export default function Projects() {
  const jarAvailable = useJarAvailability();
  return (
    <section id="projects" className="py-24 sm:py-32 scroll-mt-20 bg-secondary/30 border-y border-border">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Projects"
          title="Systems I've designed and built"
          description="A selection of backend and full-stack projects — from NBFC loan origination to media platforms and EdTech portals."
          testid="projects-section"
        />

        <Stagger className="grid md:grid-cols-2 gap-6">
          {projects.map((p, i) => (
            <FadeUp key={p.id}>
              <article
                className="group relative overflow-hidden rounded-2xl border border-border bg-card h-full flex flex-col transition-all duration-300 hover:border-primary/40 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5"
                data-testid={`project-card-${p.id}`}
              >
                <div className="relative h-48 sm:h-52 overflow-hidden">
                  <img
                    src={p.image}
                    alt={`${p.title} — ${p.subtitle}`}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" />
                  <span
                    className={`absolute top-3 right-3 inline-flex items-center gap-1.5 text-[11px] font-mono font-semibold px-2.5 py-1 rounded-full border ${
                      p.status === "In Progress"
                        ? "bg-amber-500/10 border-amber-500/30 text-amber-500"
                        : "bg-primary/10 border-primary/30 text-primary"
                    }`}
                    data-testid={`project-status-${p.id}`}
                  >
                    {p.status === "In Progress" && <Clock className="h-3 w-3" />}
                    {p.status}
                  </span>
                </div>

                <div className="p-6 flex flex-col flex-1">
                  <p className="text-xs font-mono uppercase tracking-widest text-primary mb-2">{p.category}</p>
                  <h3 className="font-heading text-xl sm:text-2xl font-semibold text-foreground flex items-center gap-2">
                    <FolderGit2 className="h-5 w-5 text-primary shrink-0" />
                    {p.title}
                  </h3>
                  <p className="text-sm text-muted-foreground font-medium mt-0.5 mb-3">{p.subtitle}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">{p.description}</p>
                  <ul className="space-y-1.5 mb-5">
                    {p.highlights.map((h, j) => (
                      <li key={j} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="text-primary mt-1">▸</span>
                        {h}
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto">
                    <div className="flex flex-wrap gap-2 mb-4">
                      {p.tech.map((t) => (
                        <span key={t} className="tag-chip">{t}</span>
                      ))}
                    </div>
                    <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
                      {p.github && (
                        <a
                          href={p.github}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-testid={`project-github-${p.id}`}
                          className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Github className="h-4 w-4" /> Code
                        </a>
                      )}
                      {p.live && (
                        <a
                          href={p.live}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-testid={`project-live-${p.id}`}
                          className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
                        >
                          <ExternalLink className="h-4 w-4" /> Live Demo
                        </a>
                      )}
                      {p.jar && (jarAvailable[p.id] ? (
                        <a
                          href={/^https?:\/\//.test(p.jar) ? p.jar : `/${p.jar}`}
                          download
                          data-testid={`project-jar-${p.id}`}
                          className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-1.5 text-xs font-semibold text-primary-foreground transition-transform duration-200 hover:-translate-y-0.5"
                        >
                          <FileDown className="h-3.5 w-3.5" /> Download JAR
                        </a>
                      ) : (
                        <span
                          data-testid={`project-jar-soon-${p.id}`}
                          className="inline-flex items-center gap-1.5 rounded-full border border-dashed border-border px-4 py-1.5 text-xs font-medium text-muted-foreground"
                        >
                          <FileWarning className="h-3.5 w-3.5" /> JAR coming soon
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </article>
            </FadeUp>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
