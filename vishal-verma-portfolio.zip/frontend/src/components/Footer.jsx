import { Github, Linkedin, Mail, ArrowUp } from "lucide-react";
import { personal, navLinks } from "../content";

export default function Footer() {
  return (
    <footer className="border-t border-border bg-secondary/30" data-testid="footer">
      <div className="mx-auto max-w-6xl px-5 sm:px-8 py-12">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2.5">
            <span className="h-9 w-9 rounded-xl bg-primary flex items-center justify-center">
              <svg viewBox="0 0 64 64" className="h-5 w-5" aria-hidden="true">
                <path d="M16 18 L28 46 L34 46 L26 18 Z" fill="#0B0F14" />
                <path d="M30 18 L42 46 L48 46 L40 18 Z" fill="#0B0F14" opacity="0.55" />
              </svg>
            </span>
            <div>
              <p className="font-heading font-bold text-foreground">vishal<span className="text-primary">.dev</span></p>
              <p className="text-xs text-muted-foreground">Java Backend Developer · Pune, India</p>
            </div>
          </div>

          <nav className="flex flex-wrap justify-center gap-x-5 gap-y-2">
            {navLinks.map((l) => (
              <a
                key={l.id}
                href={`#${l.id}`}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a href={personal.github} target="_blank" rel="noopener noreferrer" aria-label="GitHub" data-testid="footer-github" className="h-9 w-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors">
              <Github className="h-4 w-4" />
            </a>
            <a href={personal.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" data-testid="footer-linkedin" className="h-9 w-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors">
              <Linkedin className="h-4 w-4" />
            </a>
            <a href={`mailto:${personal.email}`} aria-label="Email" data-testid="footer-email" className="h-9 w-9 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors">
              <Mail className="h-4 w-4" />
            </a>
            <a href="#top" aria-label="Back to top" data-testid="footer-back-to-top" className="h-9 w-9 rounded-full bg-primary flex items-center justify-center text-primary-foreground hover:opacity-90 transition-opacity">
              <ArrowUp className="h-4 w-4" />
            </a>
          </div>
        </div>
        <p className="mt-8 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} {personal.name}. Designed & built with React and Tailwind CSS.
        </p>
      </div>
    </footer>
  );
}
