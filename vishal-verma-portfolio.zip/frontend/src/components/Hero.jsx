import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, Download, Mail, MapPin } from "lucide-react";
import { MaskedLines } from "./Motion";
import { personal } from "../content";

const fade = (delay) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] },
});

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const photoY = useTransform(scrollYProgress, [0, 1], [0, 60]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, -30]);

  return (
    <section id="top" ref={ref} className="relative min-h-screen flex items-center overflow-hidden pt-16">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.04] dark:opacity-[0.07]"
        aria-hidden="true"
        style={{
          backgroundImage:
            "linear-gradient(hsl(var(--primary)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
        }}
      />
      <div
        className="pointer-events-none absolute -top-32 -right-32 h-[480px] w-[480px] rounded-full opacity-20 dark:opacity-25 blur-3xl"
        style={{ background: "radial-gradient(circle, hsl(var(--primary) / 0.5), transparent 65%)" }}
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8 py-20 grid lg:grid-cols-[1.35fr_1fr] gap-14 items-center w-full">
        <motion.div style={{ y: textY }}>
          <motion.div {...fade(0.1)} className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 mb-7" data-testid="hero-availability">
            <span className="h-2 w-2 rounded-full bg-primary animate-pulse-dot" />
            <span className="text-xs font-mono font-medium text-primary">{personal.availability}</span>
          </motion.div>

          <MaskedLines
            as="h1"
            className="font-heading font-extrabold tracking-tight leading-[1.06] text-4xl sm:text-5xl lg:text-6xl text-foreground"
            lineClassName=""
            lines={[
              "Hi, I'm Vishal Verma.",
              <span key="l2" className="text-primary">Java Backend</span>,
              "Developer.",
            ]}
          />

          <motion.p
            {...fade(0.55)}
            className="mt-6 text-base sm:text-lg text-muted-foreground leading-relaxed max-w-xl"
            data-testid="hero-tagline"
          >
            {personal.tagline}
          </motion.p>

          <motion.div {...fade(0.7)} className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#projects"
              data-testid="hero-view-projects-btn"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:-translate-y-0.5"
            >
              View Projects
              <ArrowDown className="h-4 w-4 transition-transform duration-200 group-hover:translate-y-0.5" />
            </a>
            <a
              href="#resume"
              data-testid="hero-download-resume-btn"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors duration-200 hover:border-primary/50 hover:text-primary"
            >
              <Download className="h-4 w-4" />
              Download Resume
            </a>
            <a
              href={`mailto:${personal.email}?subject=${encodeURIComponent("Portfolio Enquiry")}`}
              data-testid="hero-enquiry-btn"
              className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors duration-200 hover:border-primary/50 hover:text-primary"
            >
              <Mail className="h-4 w-4" />
              Send an Enquiry
            </a>
          </motion.div>

          <motion.div {...fade(0.85)} className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-primary" />
            <span>{personal.location}</span>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          style={{ y: photoY }}
          className="relative justify-self-center lg:justify-self-end"
        >
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] border border-primary/25 rotate-3" aria-hidden="true" />
            <div className="absolute -inset-4 rounded-[2rem] border border-border -rotate-2" aria-hidden="true" />
            <div className="relative h-72 w-64 sm:h-96 sm:w-80 overflow-hidden rounded-[2rem] border border-border shadow-2xl">
              <img
                src={personal.profilePhoto}
                alt="Vishal Verma — Java Backend Developer portrait"
                className="h-full w-full object-cover"
                loading="eager"
                data-testid="hero-profile-photo"
              />
            </div>
            <div className="absolute -bottom-5 -left-5 rounded-xl border border-border bg-card/90 backdrop-blur px-4 py-3 shadow-lg" data-testid="hero-role-badge">
              <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Role</p>
              <p className="text-sm font-semibold text-foreground">Software Engineer</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
