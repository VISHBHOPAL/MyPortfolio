import { GraduationCap, CalendarDays, Star, Building2 } from "lucide-react";
import { SectionHeader, Stagger, FadeUp } from "./Motion";
import { education } from "../content";

export default function Education() {
  return (
    <section id="education" className="py-24 sm:py-32 scroll-mt-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Education"
          title="Academic foundation"
          testid="education-section"
        />

        <Stagger className="max-w-3xl space-y-5">
          {education.map((ed, i) => (
            <FadeUp key={i}>
              <div
                className="rounded-2xl border border-border bg-card p-6 sm:p-8 transition-colors duration-200 hover:border-primary/40"
                data-testid={`education-card-${i}`}
              >
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-primary/10 border border-primary/25 flex items-center justify-center text-primary shrink-0">
                      <GraduationCap className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-heading text-xl font-semibold text-foreground">{ed.degree}</h3>
                      <p className="text-primary font-medium mt-0.5">{ed.field}</p>
                      <p className="mt-1 text-sm text-muted-foreground flex items-center gap-1.5">
                        <Building2 className="h-3.5 w-3.5" /> {ed.institution}
                      </p>
                    </div>
                  </div>
                  <div className="text-right space-y-1.5">
                    <span className="inline-flex items-center gap-1.5 tag-chip">
                      <CalendarDays className="h-3.5 w-3.5" /> Class of {ed.year}
                    </span>
                    <p className="text-sm font-semibold text-foreground flex items-center justify-end gap-1.5">
                      <Star className="h-3.5 w-3.5 text-primary" /> {ed.score}
                    </p>
                  </div>
                </div>
                <p className="mt-5 text-sm sm:text-base text-muted-foreground leading-relaxed">{ed.notes}</p>
              </div>
            </FadeUp>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
