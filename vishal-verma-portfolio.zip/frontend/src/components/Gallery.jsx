import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { SectionHeader, Stagger, FadeUp } from "./Motion";
import { gallery } from "../content";

const filters = ["All", "Professional", "Events", "Projects", "Awards", "Other"];

export default function Gallery() {
  const [filter, setFilter] = useState("All");
  const [lightbox, setLightbox] = useState(null);

  const visible = filter === "All" ? gallery : gallery.filter((g) => g.category === filter);

  const close = useCallback(() => setLightbox(null), []);
  const step = useCallback(
    (dir) => {
      setLightbox((cur) => {
        if (cur === null) return cur;
        return (cur + dir + visible.length) % visible.length;
      });
    },
    [visible.length]
  );

  useEffect(() => {
    if (lightbox === null) return;
    const onKey = (e) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [lightbox, close, step]);

  return (
    <section id="gallery" className="py-24 sm:py-32 scroll-mt-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Photo Gallery"
          title="Moments & milestones"
          description="A glimpse into engineering meetups, team sprints and workspace life. Click any photo to open the full view."
          testid="gallery-section"
        />

        <div className="flex flex-wrap gap-2 mb-10" data-testid="gallery-filters">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => { setFilter(f); setLightbox(null); }}
              data-testid={`gallery-filter-${f.toLowerCase()}`}
              className={`px-4 py-1.5 rounded-full text-xs font-mono font-semibold border transition-colors duration-200 ${
                filter === f
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {visible.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 p-12 text-center" data-testid="gallery-empty">
            <p className="text-muted-foreground text-sm">
              No photos in this category yet — they'll appear here as they're added.
            </p>
          </div>
        ) : (
          <Stagger className="grid grid-cols-2 lg:grid-cols-3 gap-4" key={filter}>
            {visible.map((g, i) => (
              <FadeUp key={g.id}>
                <button
                  onClick={() => setLightbox(i)}
                  data-testid={`gallery-item-${g.id}`}
                  className="group relative block w-full overflow-hidden rounded-2xl border border-border aspect-[4/3] focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <img
                    src={g.src}
                    alt={g.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-left translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    <span className="tag-chip !text-[10px] mb-1.5 inline-block">{g.category}</span>
                    <p className="text-sm font-semibold text-white">{g.title}</p>
                  </div>
                </button>
              </FadeUp>
            ))}
          </Stagger>
        )}
      </div>

      <AnimatePresence>
        {lightbox !== null && visible[lightbox] && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-10"
            onClick={close}
            data-testid="gallery-lightbox"
          >
            <button
              onClick={close}
              data-testid="lightbox-close-btn"
              aria-label="Close"
              className="absolute top-5 right-5 h-10 w-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
            >
              <X className="h-5 w-5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); step(-1); }}
              data-testid="lightbox-prev-btn"
              aria-label="Previous photo"
              className="absolute left-3 sm:left-8 h-10 w-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); step(1); }}
              data-testid="lightbox-next-btn"
              aria-label="Next photo"
              className="absolute right-3 sm:right-8 h-10 w-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <motion.figure
              key={lightbox}
              initial={{ opacity: 0, scale: 0.94 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={visible[lightbox].src}
                alt={visible[lightbox].title}
                className="w-full max-h-[70vh] object-contain rounded-xl"
                data-testid="lightbox-image"
              />
              <figcaption className="mt-4 text-center">
                <p className="text-white font-semibold">{visible[lightbox].title}</p>
                <p className="mt-1 text-sm text-white/70" data-testid="lightbox-caption">{visible[lightbox].caption}</p>
              </figcaption>
            </motion.figure>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
