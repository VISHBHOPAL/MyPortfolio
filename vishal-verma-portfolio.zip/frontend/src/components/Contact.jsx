import { Mail, Phone, Linkedin, Github, MapPin, Send } from "lucide-react";
import { SectionHeader, Stagger, FadeUp, Reveal } from "./Motion";
import { personal } from "../content";

const items = [
  { icon: Mail, label: "Email", value: personal.email, href: `mailto:${personal.email}`, testid: "contact-email" },
  { icon: Phone, label: "Phone", value: personal.phone, href: `tel:${personal.phone.replace(/\s/g, "")}`, testid: "contact-phone" },
  { icon: Linkedin, label: "LinkedIn", value: personal.linkedin.replace("https://", ""), href: personal.linkedin, testid: "contact-linkedin" },
  { icon: Github, label: "GitHub", value: personal.github.replace("https://", ""), href: personal.github, testid: "contact-github" },
  { icon: MapPin, label: "Location", value: personal.location, href: null, testid: "contact-location" },
];

export default function Contact() {
  const mailto = `mailto:${personal.email}?subject=${encodeURIComponent("Portfolio Enquiry")}`;

  return (
    <section id="contact" className="py-24 sm:py-32 scroll-mt-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Contact"
          title="Let's build something robust"
          description="Open to Java / Spring Boot backend roles, freelance backend work and interesting collaborations. The fastest way to reach me is a direct enquiry."
          testid="contact-section"
        />

        <div className="grid lg:grid-cols-[1.2fr_1fr] gap-10 items-start">
          <Stagger className="space-y-3">
            {items.map((it) => {
              const Icon = it.icon;
              const inner = (
                <>
                  <div className="h-11 w-11 rounded-xl bg-primary/10 border border-primary/25 flex items-center justify-center text-primary shrink-0">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">{it.label}</p>
                    <p className="text-sm sm:text-base font-medium text-foreground truncate">{it.value}</p>
                  </div>
                </>
              );
              return (
                <FadeUp key={it.label}>
                  {it.href ? (
                    <a
                      href={it.href}
                      target={it.href.startsWith("http") ? "_blank" : undefined}
                      rel={it.href.startsWith("http") ? "noopener noreferrer" : undefined}
                      data-testid={it.testid}
                      className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-all duration-200 hover:border-primary/40 hover:-translate-y-0.5"
                    >
                      {inner}
                    </a>
                  ) : (
                    <div
                      data-testid={it.testid}
                      className="flex items-center gap-4 rounded-2xl border border-border bg-card p-4"
                    >
                      {inner}
                    </div>
                  )}
                </FadeUp>
              );
            })}
          </Stagger>

          <Reveal delay={0.1}>
            <div className="rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card p-8 sm:p-10 text-center" data-testid="enquiry-panel">
              <div className="mx-auto h-14 w-14 rounded-2xl bg-primary flex items-center justify-center text-primary-foreground mb-6">
                <Send className="h-6 w-6" />
              </div>
              <h3 className="font-heading text-2xl font-semibold text-foreground">Have an opportunity in mind?</h3>
              <p className="mt-3 text-sm sm:text-base text-muted-foreground leading-relaxed">
                One click opens your email app with my address and a pre-filled subject — tell me about the role or project.
              </p>
              <a
                href={mailto}
                data-testid="send-enquiry-btn"
                className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:-translate-y-0.5"
              >
                <Mail className="h-4 w-4" /> Send an Enquiry
              </a>
              <p className="mt-4 text-xs font-mono text-muted-foreground">
                {personal.email} · subject: "Portfolio Enquiry"
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
