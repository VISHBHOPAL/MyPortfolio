import { Briefcase, MapPin, CheckCircle2 } from "lucide-react";
import { Reveal, SectionHeader } from "./Motion";
import { experience } from "../content";

export default function Experience() {
  return (
    <section id="experience" className="py-24 sm:py-32 scroll-mt-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Work Experience"
          title="Where I've shipped production software"
          testid="experience-section"
        />

        <div className="relative space-y-10 before:absolute before:left-[7px] sm:before:left-[9px] before:top-2 before:bottom-2 before:w-px before:bg-border">
          {experience.map((job, i) => (
            <Reveal key={job.company} delay={i * 0.08}>
              <div className="relative pl-10 sm:pl-14" data-testid={`experience-item-${i}`}>
                <span className="absolute left-0 sm:left-[2px] top-1.5 h-4 w-4 rounded-full border-2 border-primary bg-background" />
                <div className="rounded-2xl border border-border bg-card p-6 sm:p-8 transition-colors duration-200 hover:border-primary/40">
                  <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                    <div>
                      <h3 className="font-heading text-xl sm:text-2xl font-semibold text-foreground flex items-center gap-2">
                        <Briefcase className="h-5 w-5 text-primary" />
                        {job.role}
                      </h3>
                      <p className="mt-1 text-base text-primary font-medium">{job.company}</p>
                    </div>
                    <div className="text-right">
                      <span className="inline-block tag-chip">{job.period}</span>
                      <p className="mt-2 text-xs text-muted-foreground flex items-center justify-end gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        {job.location}
                      </p>
                    </div>
                  </div>
                  <p className="text-sm sm:text-base text-muted-foreground leading-relaxed mb-5">{job.description}</p>
                  <ul className="space-y-2.5 mb-6">
                    {job.points.map((pt, j) => (
                      <li key={j} className="flex items-start gap-2.5 text-sm text-muted-foreground leading-relaxed">
                        <CheckCircle2 className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                        {pt}
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-2">
                    {job.tech.map((t) => (
                      <span key={t} className="tag-chip">{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
