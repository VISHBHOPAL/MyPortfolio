import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Eye, X, FileText, FileWarning } from "lucide-react";
import { SectionHeader, Reveal } from "./Motion";
import { resume, personal } from "../content";

export default function Resume() {
  const [available, setAvailable] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  useEffect(() => {
    fetch(`/${resume.file}`, { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        setAvailable(r.ok && type.includes("pdf"));
      })
      .catch(() => setAvailable(false));
  }, []);

  return (
    <section id="resume" className="py-24 sm:py-32 scroll-mt-20 bg-secondary/30 border-y border-border">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Resume"
          title="Curriculum Vitae"
          description="Review my qualifications, projects and technical trajectory — download the PDF or preview it right here."
          testid="resume-section"
        />

        <Reveal>
          <div className="rounded-2xl border border-border bg-card p-8 sm:p-12 flex flex-col sm:flex-row items-center gap-8" data-testid="resume-card">
            <div className="h-20 w-20 rounded-2xl bg-primary/10 border border-primary/25 flex items-center justify-center text-primary shrink-0">
              <FileText className="h-10 w-10" />
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h3 className="font-heading text-xl sm:text-2xl font-semibold text-foreground">
                {personal.name} — {personal.role.split("|")[0].trim()}
              </h3>
              <p className="mt-2 text-sm sm:text-base text-muted-foreground leading-relaxed">
                {available
                  ? "One page, up to date — experience, projects, skills and education in a single PDF."
                  : "The resume PDF is being updated and will be available here shortly."}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 shrink-0">
              {available ? (
                <>
                  <a
                    href={`/${resume.file}`}
                    download={resume.downloadName}
                    data-testid="resume-download-btn"
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-transform duration-200 hover:-translate-y-0.5"
                  >
                    <Download className="h-4 w-4" /> Download Resume
                  </a>
                  <button
                    onClick={() => setPreviewOpen(true)}
                    data-testid="resume-preview-btn"
                    className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-semibold text-foreground hover:border-primary/50 hover:text-primary transition-colors"
                  >
                    <Eye className="h-4 w-4" /> Preview
                  </button>
                </>
              ) : (
                <span
                  className="inline-flex items-center gap-2 rounded-full border border-dashed border-border px-6 py-3 text-sm font-medium text-muted-foreground"
                  data-testid="resume-placeholder-note"
                >
                  <FileWarning className="h-4 w-4" /> PDF coming soon
                </span>
              )}
            </div>
          </div>
        </Reveal>
      </div>

      <AnimatePresence>
        {previewOpen && available && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
            onClick={() => setPreviewOpen(false)}
            data-testid="resume-preview-modal"
          >
            <button
              onClick={() => setPreviewOpen(false)}
              aria-label="Close preview"
              data-testid="resume-preview-close-btn"
              className="absolute top-5 right-5 h-10 w-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
            >
              <X className="h-5 w-5" />
            </button>
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              className="w-full max-w-4xl h-[85vh] rounded-xl overflow-hidden bg-white"
              onClick={(e) => e.stopPropagation()}
            >
              <iframe
                src={`/${resume.file}`}
                title="Resume preview"
                className="w-full h-full"
                data-testid="resume-preview-frame"
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
