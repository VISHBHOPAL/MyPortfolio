import { motion } from "framer-motion";

const fadeUp = {
  hidden: { opacity: 0, y: 26 },
  show: { opacity: 1, y: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] } },
};

export function Reveal({ children, className = "", delay = 0 }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

export function Stagger({ children, className = "" }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      whileInView="show"
      viewport={{ once: true, margin: "-60px" }}
      variants={{ hidden: {}, show: { transition: { staggerChildren: 0.08 } } }}
    >
      {children}
    </motion.div>
  );
}

export function FadeUp({ children, className = "" }) {
  return (
    <motion.div className={className} variants={fadeUp}>
      {children}
    </motion.div>
  );
}

export function MaskedLines({ lines, as: Tag = "h1", className = "", lineClassName = "" }) {
  return (
    <Tag className={className} data-testid="masked-heading">
      {lines.map((l, i) => (
        <span key={i} className={`block overflow-hidden pb-1 ${lineClassName}`}>
          <motion.span
            className="block"
            initial={{ y: "110%" }}
            animate={{ y: "0%" }}
            transition={{ duration: 0.85, delay: 0.15 + i * 0.13, ease: [0.22, 1, 0.36, 1] }}
          >
            {l}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}

export function SectionHeader({ eyebrow, title, description, testid }) {
  return (
    <Reveal className="mb-14 max-w-3xl">
      <p className="eyebrow mb-4" data-testid={`${testid}-eyebrow`}>{eyebrow}</p>
      <h2
        className="font-heading text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground text-balance"
        data-testid={`${testid}-title`}
      >
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-base sm:text-lg text-muted-foreground leading-relaxed" data-testid={`${testid}-description`}>
          {description}
        </p>
      )}
    </Reveal>
  );
}
