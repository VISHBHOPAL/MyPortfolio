import { Cpu, Database, Users } from "lucide-react";
import { Reveal, SectionHeader, Stagger, FadeUp } from "./Motion";
import { about } from "../content";

const icons = [Cpu, Database, Users];

export default function About() {
  return (
    <section id="about" className="py-24 sm:py-32 scroll-mt-20">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="About Me"
          title="Engineering backends that stay fast under pressure"
          testid="about-section"
        />

        <div className="grid lg:grid-cols-[1.4fr_1fr] gap-10">
          <Reveal className="space-y-5">
            {about.paragraphs.map((p, i) => (
              <p key={i} className="text-base sm:text-lg text-muted-foreground leading-relaxed" data-testid={`about-paragraph-${i}`}>
                {p}
              </p>
            ))}
          </Reveal>

          <Stagger className="grid grid-cols-2 gap-4 content-start">
            {about.stats.map((s, i) => (
              <FadeUp key={s.label}>
                <div
                  className="rounded-2xl border border-border bg-card p-5 transition-colors duration-200 hover:border-primary/40"
                  data-testid={`about-stat-${i}`}
                >
                  <p className="font-heading text-3xl sm:text-4xl font-bold text-primary">{s.value}</p>
                  <p className="mt-1 text-xs font-mono uppercase tracking-wider text-muted-foreground">{s.label}</p>
                </div>
              </FadeUp>
            ))}
          </Stagger>
        </div>

        <Stagger className="mt-14 grid sm:grid-cols-3 gap-5">
          {about.highlights.map((h, i) => {
            const Icon = icons[i % icons.length];
            return (
              <FadeUp key={h.title}>
                <div
                  className="group rounded-2xl border border-border bg-card p-6 h-full transition-all duration-300 hover:border-primary/40 hover:-translate-y-1"
                  data-testid={`about-highlight-${i}`}
                >
                  <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/25 flex items-center justify-center text-primary mb-4">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-heading font-semibold text-lg text-foreground">{h.title}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{h.text}</p>
                </div>
              </FadeUp>
            );
          })}
        </Stagger>
      </div>
    </section>
  );
}
