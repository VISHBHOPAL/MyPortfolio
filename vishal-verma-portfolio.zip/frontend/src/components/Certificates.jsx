import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Award, BadgeCheck, Eye, X, FileText, Trophy } from "lucide-react";
import { SectionHeader, Stagger, FadeUp, Reveal } from "./Motion";
import { certificates, achievements } from "../content";

function CertPreview({ cert, onClose }) {
  if (!cert) return null;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-10"
      onClick={onClose}
      data-testid="certificate-lightbox"
    >
      <button
        onClick={onClose}
        aria-label="Close"
        data-testid="certificate-close-btn"
        className="absolute top-5 right-5 h-10 w-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors z-10"
      >
        <X className="h-5 w-5" />
      </button>
      <motion.figure
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="max-w-3xl w-full"
        onClick={(e) => e.stopPropagation()}
      >
        {cert.type === "pdf" ? (
          <div className="rounded-xl bg-white p-8 text-center text-gray-800">
            <FileText className="h-10 w-10 mx-auto mb-3 text-gray-500" />
            <p className="font-semibold">{cert.name}</p>
            <p className="text-sm text-gray-500 mt-1">PDF certificate — open in a new tab to view.</p>
          </div>
        ) : (
          <img src={cert.file} alt={cert.name} className="w-full max-h-[72vh] object-contain rounded-xl" />
        )}
        <figcaption className="mt-4 text-center">
          <p className="text-white font-semibold">{cert.name}</p>
          <p className="mt-1 text-sm text-white/70">{cert.issuer} · {cert.date}</p>
        </figcaption>
      </motion.figure>
    </motion.div>
  );
}

export default function Certificates() {
  const [preview, setPreview] = useState(null);

  return (
    <section id="certificates" className="py-24 sm:py-32 scroll-mt-20 bg-secondary/30 border-y border-border">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <SectionHeader
          eyebrow="Certificates & Achievements"
          title="Certifications & credentials"
          description="Verified certifications, awards and professional recognitions."
          testid="certificates-section"
        />

        {certificates.length === 0 ? (
          <Reveal>
            <div
              className="rounded-2xl border border-dashed border-primary/40 bg-card p-10 sm:p-14 text-center"
              data-testid="certificates-empty-state"
            >
              <div className="mx-auto h-14 w-14 rounded-2xl bg-primary/10 border border-primary/25 flex items-center justify-center text-primary mb-5">
                <BadgeCheck className="h-7 w-7" />
              </div>
              <h3 className="font-heading text-xl font-semibold text-foreground">Certificates coming soon</h3>
              <p className="mt-3 text-sm sm:text-base text-muted-foreground max-w-lg mx-auto leading-relaxed">
                This space is reserved for my official certifications and credentials. No sample or fake
                certificates are shown — real ones will be published here as they're issued.
              </p>
            </div>
          </Reveal>
        ) : (
          <Stagger className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {certificates.map((c, i) => (
              <FadeUp key={c.id}>
                <div
                  className="group rounded-2xl border border-border bg-card overflow-hidden h-full flex flex-col transition-all duration-300 hover:border-primary/40 hover:-translate-y-1"
                  data-testid={`certificate-card-${c.id}`}
                >
                  <button
                    onClick={() => setPreview(c)}
                    className="relative h-44 overflow-hidden bg-secondary/60 w-full focus:outline-none focus:ring-2 focus:ring-primary"
                    data-testid={`certificate-thumb-${c.id}`}
                  >
                    {c.type === "pdf" ? (
                      <div className="h-full flex items-center justify-center text-muted-foreground">
                        <FileText className="h-12 w-12" />
                      </div>
                    ) : (
                      <img src={c.file} alt={c.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                    )}
                    <span className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-sm font-semibold gap-2">
                      <Eye className="h-4 w-4" /> Preview
                    </span>
                  </button>
                  <div className="p-5 flex flex-col flex-1">
                    <h3 className="font-heading font-semibold text-lg text-foreground">{c.name}</h3>
                    <p className="mt-1 text-sm text-primary font-medium">{c.issuer}</p>
                    <p className="text-xs font-mono text-muted-foreground mt-0.5">{c.date}</p>
                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed flex-1">{c.description}</p>
                    {c.type === "pdf" ? (
                      <a
                        href={c.file}
                        target="_blank"
                        rel="noopener noreferrer"
                        data-testid={`certificate-view-btn-${c.id}`}
                        className="mt-4 inline-flex items-center justify-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-semibold text-foreground hover:border-primary/50 hover:text-primary transition-colors"
                      >
                        <FileText className="h-4 w-4" /> View Certificate
                      </a>
                    ) : (
                      <button
                        onClick={() => setPreview(c)}
                        data-testid={`certificate-view-btn-${c.id}`}
                        className="mt-4 inline-flex items-center justify-center gap-2 rounded-full border border-border px-4 py-2 text-sm font-semibold text-foreground hover:border-primary/50 hover:text-primary transition-colors"
                      >
                        <Eye className="h-4 w-4" /> View Certificate
                      </button>
                    )}
                  </div>
                </div>
              </FadeUp>
            ))}
          </Stagger>
        )}

        {achievements.length > 0 && (
          <div className="mt-14">
            <Reveal>
              <h3 className="font-heading text-xl sm:text-2xl font-semibold text-foreground flex items-center gap-2 mb-6">
                <Trophy className="h-5 w-5 text-primary" /> Achievements
              </h3>
            </Reveal>
            <Stagger className="grid sm:grid-cols-2 gap-4">
              {achievements.map((a) => (
                <FadeUp key={a.id}>
                  <div className="rounded-2xl border border-border bg-card p-5 flex items-start gap-4" data-testid={`achievement-${a.id}`}>
                    <div className="h-10 w-10 rounded-lg bg-primary/10 border border-primary/25 flex items-center justify-center text-primary shrink-0">
                      <Award className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{a.title}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">{a.detail}</p>
                      <p className="text-xs font-mono text-primary mt-1">{a.year}</p>
                    </div>
                  </div>
                </FadeUp>
              ))}
            </Stagger>
          </div>
        )}
      </div>

      <AnimatePresence>
        {preview && <CertPreview cert={preview} onClose={() => setPreview(null)} />}
      </AnimatePresence>
    </section>
  );
}
