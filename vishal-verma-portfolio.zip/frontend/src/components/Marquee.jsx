import { marqueeItems } from "../content";

export default function Marquee() {
  const row = [...marqueeItems, ...marqueeItems];
  return (
    <div
      className="relative border-y border-border bg-secondary/40 py-3.5 overflow-hidden"
      aria-hidden="true"
      data-testid="tech-marquee"
    >
      <div className="flex w-max animate-marquee gap-10">
        {row.map((item, i) => (
          <span
            key={i}
            className="flex items-center gap-10 text-xs font-mono uppercase tracking-[0.22em] text-muted-foreground whitespace-nowrap"
          >
            {item}
            <span className="text-primary">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
