// ======================================================================
//  CONTENT CONFIGURATION — Edit this file to update the whole website.
//  No other coding is needed for content changes.
//
//  File folders (replace/add files, then update the matching entry here):
//    /public/images/profile/       -> your profile photo
//    /public/images/gallery/       -> gallery photos
//    /public/images/projects/      -> project cover images
//    /public/certificates/         -> certificate images or PDFs
//    /public/resume/               -> your resume PDF
//  A relative path like "images/gallery/my-photo.jpg" resolves inside
//  /public. Full "https://..." URLs are also supported.
// ======================================================================

export const personal = {
  name: "Vishal Verma",
  initials: "VV",
  role: "Java Backend Developer | Software Engineer",
  tagline:
    "I build resilient, high-throughput backend systems with Java and Spring Boot — clean REST APIs, optimised persistence layers, and enterprise services that hold up under real load.",
  // ==== EDIT YOUR CONTACT DETAILS HERE ====
  email: "vishal.verma.dev@gmail.com",
  phone: "+91 98765 43210",
  linkedin: "https://linkedin.com/in/vishal-verma-backend",
  github: "https://github.com/vishalverma-dev",
  location: "Pune, Maharashtra, India",
  availability: "Available for Java / Spring Boot roles",
  // ==== PROFILE PHOTO ====
  // Drop your photo into /public/images/profile/ and set the path below,
  // e.g. "images/profile/vishal.jpg"
  profilePhoto:
    "https://images.unsplash.com/photo-1566753323558-f4e0952af115?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NTJ8MHwxfHNlYXJjaHwxfHxzb2Z0d2FyZSUyMGRldmVsb3BlciUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsfGVufDB8fHx8MTc5NTEwMjIyMHww&ixlib=rb-4.1.0&q=85",
};

export const about = {
  paragraphs: [
    "I'm a Java Backend Developer with around two years of professional experience at Amedea Infotech, Pune, where I designed and shipped enterprise REST services, optimised persistence layers, and containerised deployments for fintech and edtech products.",
    "My core strength is the Spring ecosystem — Spring Boot, Spring MVC, Hibernate and JPA — backed by strong fundamentals in relational schema design, query optimisation and clean API contracts. I care about transactional correctness, readable code, and systems that fail gracefully under load.",
    "Beyond the backend, I'm comfortable wiring up React frontends, automating builds with Maven, testing APIs thoroughly in Postman, and shipping with Docker. I'm currently deepening my knowledge of microservices patterns and high-concurrency design.",
  ],
  highlights: [
    {
      title: "Backend-First Engineering",
      text: "High-throughput Spring Boot services with clean layering, validation, and predictable error handling.",
    },
    {
      title: "Data & Performance",
      text: "JPA/Hibernate tuning, indexing strategy, and caching to keep MySQL round-trips minimal and fast.",
    },
    {
      title: "Team & Delivery",
      text: "Agile collaboration at Amedea Infotech — API contracts, code reviews, Maven builds and Docker delivery.",
    },
  ],
  stats: [
    { value: "~2", label: "Years of Experience" },
    { value: "4+", label: "Projects Delivered" },
    { value: "8.41", label: "B.Tech CGPA" },
    { value: "10+", label: "Technologies Used" },
  ],
};

export const skillCategories = [
  {
    name: "Programming Languages",
    icon: "Code2",
    skills: [
      { name: "Java (Core & Advanced)", icon: "Coffee" },
      { name: "JavaScript (ES6+)", icon: "Braces" },
    ],
  },
  {
    name: "Backend & Frameworks",
    icon: "Server",
    skills: [
      { name: "Spring Boot", icon: "Leaf" },
      { name: "Spring MVC", icon: "Workflow" },
      { name: "REST APIs", icon: "Globe" },
      { name: "Hibernate", icon: "Layers" },
      { name: "JPA", icon: "Database" },
      { name: "Microservices", icon: "Boxes" },
    ],
  },
  {
    name: "Databases",
    icon: "Database",
    skills: [
      { name: "MySQL", icon: "Database" },
      { name: "Query Optimization", icon: "Gauge" },
      { name: "Schema Design", icon: "Table" },
      { name: "Indexing", icon: "ListOrdered" },
    ],
  },
  {
    name: "Tools & DevOps",
    icon: "Wrench",
    skills: [
      { name: "Git", icon: "GitBranch" },
      { name: "GitHub", icon: "Github" },
      { name: "Maven", icon: "Package" },
      { name: "Postman", icon: "Send" },
      { name: "Docker", icon: "Container" },
      { name: "Linux CLI", icon: "Terminal" },
    ],
  },
  {
    name: "Frontend",
    icon: "Monitor",
    skills: [
      { name: "HTML5", icon: "FileCode" },
      { name: "CSS3", icon: "Palette" },
      { name: "React", icon: "Atom" },
      { name: "Tailwind CSS", icon: "Wind" },
    ],
  },
];

export const experience = [
  {
    company: "Amedea Infotech",
    role: "Java Developer / Spring Boot Developer",
    period: "Approx. 2 Years", // Do NOT mark as current employment — keep editable
    current: false,
    location: "Pune, Maharashtra",
    // ==== EDIT THE DESCRIPTION FREELY ====
    description:
      "Worked on enterprise backend development across fintech and edtech products, building and maintaining Spring Boot services from design to deployment.",
    points: [
      "Designed and maintained resilient REST APIs handling high transaction volumes with consistent sub-100ms response targets.",
      "Optimised JPA/Hibernate queries and caching, reducing database round-trips significantly on core transaction flows.",
      "Implemented authentication, role-based access control, and automated Maven build pipelines with Dockerised delivery.",
    ],
    tech: ["Java", "Spring Boot", "Hibernate", "JPA", "MySQL", "REST APIs", "Maven", "Docker", "Git"],
  },
];

export const projects = [
  {
    id: "nbfc-dsa360",
    title: "NBFC DSA360",
    subtitle: "Direct Selling Agent Platform",
    category: "Fintech / Enterprise Backend",
    description:
      "Comprehensive loan origination and agent-distribution management system for Non-Banking Financial Companies, covering lead lifecycles, multi-tier commission calculation and audit logging.",
    highlights: [
      "Engineered multi-stage loan application workflows with deterministic state transitions.",
      "Built an automated commission calculation engine with audit-proof transaction ledgers.",
    ],
    tech: ["Java", "Spring Boot", "MySQL", "Hibernate", "REST APIs"],
    // Add your own links when ready (leave empty to hide the buttons)
    github: "",
    live: "",
    // Downloadable JAR: drop the file into /public/jars/ and set the path
    // below (e.g. "jars/nbfc-dsa360.jar"), or paste a full https:// link.
    // Leave "" to hide the button.
    jar: "jars/nbfc-dsa360.jar",
    status: "Completed",
    image:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
  },
  {
    id: "reelflow",
    title: "ReelFlow",
    subtitle: "Short-Form Video Platform",
    category: "Full-Stack / Media",
    description:
      "A short-video sharing platform with a React frontend and Spring Boot backend — secure JWT authentication, media upload pipelines, and a feed served by optimised metadata queries.",
    highlights: [
      "Implemented JWT-based auth with refresh rotation and role-protected endpoints.",
      "Optimised MySQL indexes for fast, paginated video feed retrieval.",
    ],
    tech: ["React", "Spring Boot", "MySQL", "JWT"],
    github: "",
    live: "",
    jar: "jars/reelflow.jar",
    status: "Completed",
    image:
      "https://images.unsplash.com/photo-1536240478700-b869070f9279?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
  },
  {
    id: "rising-asap-academy",
    title: "Rising ASAP Academy",
    subtitle: "EdTech Management Portal",
    category: "EdTech / Full-Stack",
    description:
      "Course scheduling, student enrolment and progress-tracking platform with secure authentication and dedicated dashboards for students, trainers and administrators.",
    highlights: [
      "Developed modular enrolment and attendance-tracking REST APIs.",
      "Implemented transactional course purchase and completion certificate triggers.",
    ],
    tech: ["React", "Spring Boot", "MySQL"],
    github: "",
    live: "",
    jar: "jars/rising-asap-academy.jar",
    status: "Completed",
    image:
      "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
  },
  {
    id: "event-management-platform",
    title: "Event Management Platform",
    subtitle: "Ticketing & Venue Booking",
    category: "Enterprise Services",
    description:
      "High-concurrency ticket reservation and venue seating service with real-time attendee notifications — currently in active development.",
    highlights: [
      "Addressing double-booking race conditions using optimistic locking in JPA.",
      "Designing microservice boundaries for ticketing, seating and notifications.",
    ],
    tech: ["Spring Boot", "Microservices", "MySQL", "Docker", "React"],
    github: "",
    live: "",
    jar: "jars/event-management-platform.jar",
    status: "In Progress",
    image:
      "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
  },
];

// ==== GALLERY ====
// To add a photo: drop the file into /public/images/gallery/, then add an
// entry below, e.g. { id: "g7", title: "...", caption: "...",
// category: "Events", src: "images/gallery/my-photo.jpg" }
// To remove one: delete its entry. Categories: Professional | Events |
// Projects | Awards | Other
export const gallery = [
  {
    id: "gal-1",
    title: "Architecting High-Throughput Services",
    category: "Professional",
    src: "https://images.unsplash.com/photo-1675869940341-d495d49010b5?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Deep-focus coding sprint: profiling Spring Boot REST endpoints and tuning Hibernate queries.",
  },
  {
    id: "gal-2",
    title: "Tech Community Presentation",
    category: "Events",
    src: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Sharing architectural insights on building resilient backend services at a developer meetup.",
  },
  {
    id: "gal-3",
    title: "Developer Workstation & Setup",
    category: "Projects",
    src: "https://images.unsplash.com/photo-1650661926447-9efb2610f64c?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Clean workstation environment optimised for full-stack engineering and rapid prototyping.",
  },
  {
    id: "gal-4",
    title: "Annual Developer Summit",
    category: "Events",
    src: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Attending a developer summit covering cloud-scale patterns and modern Java features.",
  },
  {
    id: "gal-5",
    title: "Evening Architecture Review",
    category: "Professional",
    src: "https://images.unsplash.com/photo-1604145559206-e3bce0040e2d?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Late-evening code review and release verification for an enterprise deployment.",
  },
  {
    id: "gal-6",
    title: "System Design & Brainstorming",
    category: "Other",
    src: "https://images.unsplash.com/photo-1582192730841-2a682d7375f9?crop=entropy&cs=srgb&fm=jpg&q=85&w=1080",
    caption: "Panel discussion on microservice observability, logging best practices and Docker deployments.",
  },
];

// ==== CERTIFICATES ====
// This section starts EMPTY on purpose — no fake certificates.
// To add one: drop the image (JPG/JPEG/PNG) or PDF into /public/certificates/
// and add an entry:
//   { id: "c1", name: "Java SE 11 Developer", issuer: "Oracle",
//     date: "March 2025", description: "...",
//     file: "certificates/java-se11.pdf", type: "pdf" }
// type: "image" | "pdf" — PDFs open in a new browser tab.
export const certificates = [];

// ==== ACHIEVEMENTS ====
// Starts EMPTY — add your real awards, competitions and recognitions here.
//   { id: "a1", title: "...", detail: "...", year: "2024" }
export const achievements = [];

export const education = [
  {
    degree: "Bachelor of Technology (B.Tech)",
    field: "Information Technology",
    year: "2024",
    score: "8.41 CGPA",
    institution: "Savitribai Phule Pune University",
    notes:
      "Coursework across data structures & algorithms, database systems, object-oriented software engineering, operating systems and computer networks.",
  },
];

// ==== RESUME ====
// Drop your resume PDF into /public/resume/ and update the path below.
// If no PDF is present yet, the site shows a clear placeholder notice.
export const resume = {
  file: "resume/Vishal_Verma_Resume.pdf",
  downloadName: "Vishal_Verma_Java_Backend_Developer_Resume.pdf",
};

export const navLinks = [
  { id: "about", label: "About" },
  { id: "skills", label: "Skills" },
  { id: "experience", label: "Experience" },
  { id: "projects", label: "Projects" },
  { id: "gallery", label: "Gallery" },
  { id: "certificates", label: "Certificates" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
];

export const marqueeItems = [
  "Java 21",
  "Spring Boot",
  "Microservices",
  "REST APIs",
  "Hibernate / JPA",
  "MySQL",
  "Docker",
  "High Concurrency",
  "Distributed Systems",
  "Maven",
  "Postman",
  "Git & GitHub",
];
